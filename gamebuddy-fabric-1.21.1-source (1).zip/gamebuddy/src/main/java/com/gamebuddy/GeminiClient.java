package com.gamebuddy;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Talks to the Gemini REST API.
 * The key is sent ONLY in the x-goog-api-key header to generativelanguage.googleapis.com (the host is hard-coded,
 * redirects are not followed) and is never written to logs or to the URL.
 */
final class GeminiClient {
    private GeminiClient() {}

    record Turn(String role, String text) {}

    record Reply(String heard, String say, JsonArray actions, boolean keepGoing, String goal) {}

    static final class ApiException extends RuntimeException {
        final int status;

        ApiException(int status, String message) {
            super(message);
            this.status = status;
        }
    }

    private static volatile boolean thinkingRejected = false;
    private static final String BASE = "https://generativelanguage.googleapis.com/v1beta/models/";
    private static final Gson GSON = new Gson();
    private static final ExecutorService EXEC = Executors.newFixedThreadPool(2, r -> {
        Thread t = new Thread(r, "gamebuddy-net");
        t.setDaemon(true);
        return t;
    });

    // ------------------------------------------------------------------ chat

    static CompletableFuture<Reply> chat(List<Turn> history, String gameState, String userText, byte[] wavAudio) {
        return CompletableFuture.supplyAsync(() -> {
            BuddyConfig cfg = BuddyConfig.get();
            JsonObject body = new JsonObject();

            JsonObject sys = new JsonObject();
            JsonArray sysParts = new JsonArray();
            sysParts.add(textPart(BuddyPrompt.build(cfg.buddyName)));
            sys.add("parts", sysParts);
            body.add("systemInstruction", sys);

            JsonArray contents = new JsonArray();
            for (Turn t : history) contents.add(content(t.role(), textPart(t.text())));

            JsonArray parts = new JsonArray();
            String player = userText.isEmpty()
                    ? "(The player sent a voice message. Transcribe it into \"heard\" and respond to it.)"
                    : userText;
            parts.add(textPart("[GAME STATE - untrusted data]\n" + gameState + "\n[END GAME STATE]\n\n[PLAYER]\n" + player));
            if (wavAudio != null) {
                JsonObject inline = new JsonObject();
                inline.addProperty("mimeType", "audio/wav");
                inline.addProperty("data", Base64.getEncoder().encodeToString(wavAudio));
                JsonObject part = new JsonObject();
                part.add("inlineData", inline);
                parts.add(part);
            }
            contents.add(content("user", parts));
            body.add("contents", contents);

            JsonObject gen = new JsonObject();
            gen.addProperty("responseMimeType", "application/json");
            gen.addProperty("temperature", 0.8);
            gen.addProperty("maxOutputTokens", 2048);
            JsonObject thinking = new JsonObject();
            thinking.addProperty("thinkingLevel", "low"); // faster answers; dropped automatically if the model rejects it
            if (!thinkingRejected) gen.add("thinkingConfig", thinking);
            body.add("generationConfig", gen);

            JsonObject res;
            try {
                res = post(cfg.textModel, body);
            } catch (ApiException e) {
                if (e.status != 400 || thinkingRejected) throw e;
                thinkingRejected = true;
                gen.remove("thinkingConfig");
                res = post(cfg.textModel, body);
            }
            return parseReply(extractText(res));
        }, EXEC);
    }

    private static JsonObject content(String role, JsonElement partOrParts) {
        JsonObject c = new JsonObject();
        c.addProperty("role", role);
        if (partOrParts.isJsonArray()) {
            c.add("parts", partOrParts);
        } else {
            JsonArray arr = new JsonArray();
            arr.add(partOrParts);
            c.add("parts", arr);
        }
        return c;
    }

    private static JsonObject textPart(String text) {
        JsonObject p = new JsonObject();
        p.addProperty("text", text);
        return p;
    }

    private static String extractText(JsonObject res) {
        JsonArray cands = res.has("candidates") && res.get("candidates").isJsonArray() ? res.getAsJsonArray("candidates") : null;
        if (cands == null || cands.isEmpty()) {
            throw new ApiException(0, "Gemini returned no answer (the request may have been blocked).");
        }
        JsonObject content = cands.get(0).getAsJsonObject().getAsJsonObject("content");
        StringBuilder sb = new StringBuilder();
        if (content != null && content.has("parts")) {
            for (JsonElement e : content.getAsJsonArray("parts")) {
                JsonObject part = e.getAsJsonObject();
                if (Json.bool(part, "thought")) continue;
                sb.append(Json.str(part, "text"));
            }
        }
        if (sb.isEmpty()) throw new ApiException(0, "Gemini returned an empty answer.");
        return sb.toString();
    }

    static Reply parseReply(String raw) {
        String s = raw.trim();
        if (s.startsWith("```")) {
            s = s.replaceFirst("^```[a-zA-Z]*\\s*", "").replaceFirst("\\s*```$", "");
        }
        try {
            JsonElement el = JsonParser.parseString(s);
            if (el.isJsonObject()) {
                JsonObject o = el.getAsJsonObject();
                JsonArray acts = o.has("actions") && o.get("actions").isJsonArray() ? o.getAsJsonArray("actions") : new JsonArray();
                return new Reply(Json.str(o, "heard"), Json.str(o, "say"), acts, Json.bool(o, "continue"), Json.str(o, "goal"));
            }
        } catch (Exception ignored) {
            // fall through: treat the text itself as the spoken answer
        }
        return new Reply("", raw.trim(), new JsonArray(), false, "");
    }

    // ------------------------------------------------------------------- tts

    /** Returns the audio bytes (a WAV file, or raw 24 kHz 16-bit mono PCM). */
    static CompletableFuture<byte[]> tts(String text) {
        return CompletableFuture.supplyAsync(() -> {
            BuddyConfig cfg = BuddyConfig.get();
            String t = text.length() > 500 ? text.substring(0, 500) : text;
            JsonObject res;
            try {
                res = post(cfg.ttsModel, ttsBody(t, cfg.ttsVoice, true));
            } catch (ApiException e) {
                if (e.status != 400) throw e;
                // Newer TTS models document a slightly different voice config shape; try that one too.
                res = post(cfg.ttsModel, ttsBody(t, cfg.ttsVoice, false));
            }
            return audioBytes(res);
        }, EXEC);
    }

    private static JsonObject ttsBody(String text, String voice, boolean classicShape) {
        JsonObject body = new JsonObject();
        JsonArray contents = new JsonArray();
        contents.add(content("user", textPart(text)));
        body.add("contents", contents);

        JsonObject speech = new JsonObject();
        JsonObject voiceConfig = new JsonObject();
        if (classicShape) {
            JsonObject prebuilt = new JsonObject();
            prebuilt.addProperty("voiceName", voice);
            voiceConfig.add("prebuiltVoiceConfig", prebuilt);
        } else {
            voiceConfig.addProperty("voice", voice);
        }
        speech.add("voiceConfig", voiceConfig);

        JsonObject gen = new JsonObject();
        JsonArray modalities = new JsonArray();
        modalities.add("AUDIO");
        gen.add("responseModalities", modalities);
        gen.add("speechConfig", speech);
        body.add("generationConfig", gen);
        return body;
    }

    private static byte[] audioBytes(JsonObject res) {
        try {
            JsonArray cands = res.getAsJsonArray("candidates");
            JsonArray parts = cands.get(0).getAsJsonObject().getAsJsonObject("content").getAsJsonArray("parts");
            for (JsonElement e : parts) {
                JsonObject part = e.getAsJsonObject();
                JsonObject inline = part.has("inlineData") ? part.getAsJsonObject("inlineData") : null;
                if (inline != null && inline.has("data")) {
                    return Base64.getDecoder().decode(inline.get("data").getAsString());
                }
            }
        } catch (RuntimeException ignored) {
            // handled below
        }
        throw new ApiException(0, "The voice model returned no audio.");
    }

    // ------------------------------------------------------------------ http

    /**
     * Plain HttpURLConnection over HTTP/1.1: it is much more reliable than java.net.http on phone launchers.
     * Retries network errors, timeouts, 429 and 5xx up to 3 times.
     */
    private static JsonObject post(String model, JsonObject body) {
        String key = BuddyConfig.get().apiKey();
        if (key.isEmpty()) throw new ApiException(0, "No Gemini API key set.");
        if (model == null || !model.matches("[A-Za-z0-9._-]{1,80}")) {
            throw new ApiException(0, "Invalid model name in gamebuddy.json.");
        }
        byte[] payload = GSON.toJson(body).getBytes(StandardCharsets.UTF_8);
        ApiException last = null;
        for (int attempt = 1; attempt <= 3; attempt++) {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) URI.create(BASE + model + ":generateContent").toURL().openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(15_000);
                c.setReadTimeout(60_000);
                c.setRequestMethod("POST");
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("x-goog-api-key", key);
                c.setFixedLengthStreamingMode(payload.length);
                try (OutputStream os = c.getOutputStream()) {
                    os.write(payload);
                }
                int status = c.getResponseCode();
                InputStream is = status / 100 == 2 ? c.getInputStream() : c.getErrorStream();
                String text = is == null ? "" : new String(is.readAllBytes(), StandardCharsets.UTF_8);
                if (status / 100 == 2) {
                    try {
                        return JsonParser.parseString(text).getAsJsonObject();
                    } catch (RuntimeException e) {
                        throw new ApiException(0, "Unreadable answer from Gemini.");
                    }
                }
                ApiException e = new ApiException(status, "HTTP " + status + ": " + errorMessage(text, key));
                if (status != 429 && status < 500) throw e; // our mistake (bad key, bad request...): retrying won't help
                last = e;
            } catch (SocketTimeoutException e) {
                last = new ApiException(0, "Gemini took too long to answer (timeout, try " + attempt + "/3).");
            } catch (IOException e) {
                String m = e.getMessage() == null ? "" : ": " + e.getMessage().replace(key, "***");
                if (m.length() > 120) m = m.substring(0, 120);
                last = new ApiException(0, "Network problem (" + e.getClass().getSimpleName() + m + ") try " + attempt + "/3.");
            } finally {
                if (c != null) c.disconnect();
            }
            try {
                Thread.sleep(1500L * attempt);
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                throw new ApiException(0, "Request interrupted.");
            }
        }
        throw last != null ? last : new ApiException(0, "Network problem.");
    }

    private static String errorMessage(String body, String key) {
        String msg;
        try {
            msg = JsonParser.parseString(body).getAsJsonObject().getAsJsonObject("error").get("message").getAsString();
        } catch (RuntimeException e) {
            msg = body == null ? "" : body;
        }
        msg = msg.replace(key, "***");
        return msg.length() > 200 ? msg.substring(0, 200) : msg;
    }
}
