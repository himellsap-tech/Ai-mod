package com.gamebuddy;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.shape.VoxelShape;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * A purely client-side "player" that follows you around so Buddy feels present in your world.
 * It exists only on YOUR screen (the server never hears about it), which is why it works on any server.
 * If anything about it ever throws, it switches itself off instead of crashing the game.
 */
public final class Companion {
    private Companion() {}

    private static final UUID ID = UUID.nameUUIDFromBytes("gamebuddy:companion".getBytes(StandardCharsets.UTF_8));
    private static final int ENTITY_ID = -4242; // negative: can never clash with a real server entity id
    private static OtherClientPlayerEntity avatar;

    public static Entity entity() {
        return avatar;
    }

    public static void reset() {
        avatar = null;
    }

    /** Call at the END of each client tick so the movement interpolates smoothly. */
    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null) {
            avatar = null;
            return;
        }
        if (!BuddyConfig.get().showAvatar) {
            remove(w);
            return;
        }
        try {
            if (avatar == null || avatar.getWorld() != w || avatar.isRemoved()) spawn(p, w);
            follow(p, w);
        } catch (Throwable t) {
            GameBuddyClient.LOGGER.warn("Buddy avatar turned itself off: {}", t.toString());
            BuddyConfig.get().showAvatar = false;
            try {
                remove(w);
            } catch (Throwable ignored) {
                avatar = null;
            }
        }
    }

    private static void spawn(ClientPlayerEntity p, ClientWorld w) {
        String name = BuddyConfig.get().buddyName.replaceAll("[^A-Za-z0-9_]", "");
        if (name.isEmpty()) name = "Buddy";
        if (name.length() > 16) name = name.substring(0, 16);
        OtherClientPlayerEntity e = new OtherClientPlayerEntity(w, new GameProfile(ID, name));
        e.setId(ENTITY_ID);
        double[] s = spot(p);
        e.refreshPositionAndAngles(s[0], p.getY(), s[1], p.getYaw(), 0f);
        w.addEntity(e);
        avatar = e;
    }

    private static void remove(ClientWorld w) {
        if (avatar != null) {
            if (avatar.getWorld() == w && !avatar.isRemoved()) {
                w.removeEntity(avatar.getId(), Entity.RemovalReason.DISCARDED);
            }
            avatar = null;
        }
    }

    /** Where Buddy likes to stand: about 2 blocks behind you and a little to your right. */
    private static double[] spot(ClientPlayerEntity p) {
        double yaw = Math.toRadians(p.getYaw());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);   // facing
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);  // your right-hand side
        return new double[]{p.getX() - fx * 2.2 + rx * 1.6, p.getZ() - fz * 2.2 + rz * 1.6};
    }

    private static void follow(ClientPlayerEntity p, ClientWorld w) {
        double[] s = spot(p);
        double dxp = p.getX() - avatar.getX(), dzp = p.getZ() - avatar.getZ();
        double distToPlayer = Math.sqrt(dxp * dxp + dzp * dzp);
        if (distToPlayer > 20 || Math.abs(p.getY() - avatar.getY()) > 12) {
            avatar.refreshPositionAndAngles(s[0], p.getY(), s[1], p.getYaw(), 0f);
            return;
        }

        double dx = s[0] - avatar.getX(), dz = s[1] - avatar.getZ();
        double d = Math.sqrt(dx * dx + dz * dz);
        float targetYaw;
        if (d > 0.6) {
            double speed = Math.min(d > 5 ? 0.5 : 0.28, d * 0.25);
            double nx = avatar.getX() + dx / d * speed;
            double nz = avatar.getZ() + dz / d * speed;
            double ground = groundY(w, nx, p.getY() + 1.5, nz);
            double ny = Double.isNaN(ground) ? p.getY() : ground;
            // rise quickly (steps), fall gently
            double cy = avatar.getY();
            ny = ny > cy ? Math.min(ny, cy + 0.6) : Math.max(ny, cy - 0.6);
            avatar.setPosition(nx, ny, nz);
            targetYaw = (float) (MathHelper.atan2(dz, dx) * 57.29577951308232) - 90f;
        } else {
            targetYaw = (float) (MathHelper.atan2(dzp, dxp) * 57.29577951308232) - 90f; // idle: look at you
        }
        float yaw = avatar.getYaw() + MathHelper.clamp(MathHelper.wrapDegrees(targetYaw - avatar.getYaw()), -20f, 20f);
        avatar.setYaw(yaw);
        avatar.setHeadYaw(yaw);
        avatar.setBodyYaw(yaw);
        avatar.setPitch(0f);
    }

    private static double groundY(ClientWorld w, double x, double startY, double z) {
        BlockPos.Mutable m = new BlockPos.Mutable();
        int top = MathHelper.floor(startY);
        for (int y = top; y > top - 10; y--) {
            m.set(MathHelper.floor(x), y, MathHelper.floor(z));
            VoxelShape shape = w.getBlockState(m).getCollisionShape(w, m);
            if (!shape.isEmpty()) return y + shape.getMax(Direction.Axis.Y);
        }
        return Double.NaN;
    }
}
