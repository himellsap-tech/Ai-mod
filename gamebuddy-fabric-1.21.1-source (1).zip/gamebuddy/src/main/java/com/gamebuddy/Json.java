package com.gamebuddy;

import com.google.gson.JsonObject;

/** Tiny null-safe helpers for reading loosely shaped JSON from the AI. */
final class Json {
    private Json() {}

    static String str(JsonObject o, String key) {
        if (o == null || !o.has(key) || o.get(key).isJsonNull()) return "";
        try {
            return o.get(key).getAsString();
        } catch (Exception e) {
            return "";
        }
    }

    static double num(JsonObject o, String key, double def) {
        if (o == null || !o.has(key) || o.get(key).isJsonNull()) return def;
        try {
            double v = o.get(key).getAsDouble();
            return Double.isNaN(v) || Double.isInfinite(v) ? def : v;
        } catch (Exception e) {
            return def;
        }
    }

    static boolean bool(JsonObject o, String key) {
        if (o == null || !o.has(key) || o.get(key).isJsonNull()) return false;
        try {
            return o.get(key).getAsBoolean();
        } catch (Exception e) {
            return false;
        }
    }
}
