package com.gamebuddy;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Runs the actions Gemini asks for by pressing the SAME keys and moving the SAME camera a human would.
 * No packets are forged and nothing is injected into the game; this is just automated keyboard/mouse input.
 * It is checked every tick and cancelled on danger, when you press the stop key, and it pauses while a menu is open.
 */
public final class ActionRunner {
    private ActionRunner() {}

    private static final int MOVING = 0, ARRIVED = 1, FAILED = 2;
    private static final int MAX_ACTIONS = 8;

    private static final Deque<JsonObject> queue = new ArrayDeque<>();
    private static final Set<KeyBinding> held = new HashSet<>();
    private static JsonObject cur;
    private static int ticks;
    private static int limit;
    private static int stuck;
    private static Vec3d anchor;
    private static Vec3d lastCheck;
    private static BlockPos blockTarget;

    public static boolean active() {
        return cur != null || !queue.isEmpty();
    }

    // ------------------------------------------------------------------ control

    /** Starts a new batch of actions. Returns true if something was queued. */
    public static boolean start(JsonArray actions) {
        MinecraftClient mc = MinecraftClient.getInstance();
        BuddyConfig cfg = BuddyConfig.get();
        if (mc.player == null) return false;
        if (!cfg.allowCharacterControl) {
            BuddyHud.say("Character control is turned off in my menu.");
            return false;
        }
        if (!mc.isInSingleplayer() && !cfg.allowControlOnServers) {
            BuddyHud.say("Character control is disabled on servers in my config.");
            return false;
        }
        reset();
        int n = 0;
        for (JsonElement e : actions) {
            if (n >= MAX_ACTIONS) break;
            if (e.isJsonObject()) {
                queue.add(e.getAsJsonObject());
                n++;
            }
        }
        return n > 0;
    }

    /** Stops everything (and any AFK task) and releases every key Buddy is holding. */
    public static void cancel(String message) {
        reset();
        BuddyBrain.endTask();
        if (message != null) BuddyHud.say(message);
    }

    /** Clears the queue and releases keys, without touching the AFK task. */
    private static void reset() {
        queue.clear();
        cur = null;
        ticks = 0;
        releaseAll();
        BuddyHud.setAction("");
    }

    /** Something went wrong inside an action: end the current batch AND the AFK task. */
    private static void abort() {
        queue.clear();
        BuddyBrain.endTask();
    }

    // --------------------------------------------------------------------- tick

    /** Call at the START of every client tick, before the game reads your keys. */
    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) {
            if (active() || BuddyBrain.taskActive()) cancel(null);
            return;
        }
        if (!active()) return;
        if (mc.currentScreen != null) { // paused while a menu is open
            releaseAll();
            return;
        }
        BuddyConfig cfg = BuddyConfig.get();
        if (cfg.stopWhenDanger && (p.isInLava() || p.isOnFire() || p.getHealth() <= 6.0f)) {
            cancel("Danger! I stopped.");
            return;
        }
        if (BuddyBrain.taskActive() && p.hurtTime > 0) { // AFK safety: something is hurting us
            cancel("Something is hurting me, so I stopped the task.");
            return;
        }
        if (cur == null) {
            cur = queue.poll();
            if (cur == null) return;
            ticks = 0;
            stuck = 0;
            anchor = null;
            lastCheck = null;
            blockTarget = null;
            String type = typeOf(cur);
            limit = Math.max(1, (int) (secondsFor(type) * 20));
            BuddyHud.setAction(type);
        }

        boolean finished;
        try {
            finished = step(mc, p, typeOf(cur));
        } catch (RuntimeException e) {
            GameBuddyClient.LOGGER.warn("Action failed: {}", e.toString());
            abort();
            finished = true;
        }
        ticks++;
        if (ticks >= limit) finished = true;
        if (finished) {
            releaseAll();
            cur = null;
            if (queue.isEmpty()) {
                BuddyHud.setAction("");
                BuddyBrain.onActionsDone(); // in AFK task mode this asks Gemini for the next batch
            }
        }
    }

    private static String typeOf(JsonObject o) {
        return Json.str(o, "type").toLowerCase(Locale.ROOT);
    }

    private static double secondsFor(String type) {
        double max = Math.max(1, BuddyConfig.get().maxActionSeconds);
        double def = switch (type) {
            case "walk_to", "mine_block", "tunnel" -> max;
            case "follow_player", "attack_nearest" -> 10;
            case "look", "look_at" -> 3;
            default -> 1;
        };
        return Math.min(max, Json.num(cur, "seconds", def));
    }

    private static boolean step(MinecraftClient mc, ClientPlayerEntity p, String type) {
        return switch (type) {
            case "wait" -> false; // the time limit ends it
            case "stop" -> {
                abort();
                yield true;
            }
            case "look" -> turnTo(p, (float) Json.num(cur, "yaw", p.getYaw()), (float) Json.num(cur, "pitch", p.getPitch()));
            case "look_at" -> faceTarget(p, new Vec3d(Json.num(cur, "x", p.getX()), Json.num(cur, "y", p.getEyeY()), Json.num(cur, "z", p.getZ())));
            case "walk_to" -> stepWalk(mc, p);
            case "hold" -> stepHold(mc, p);
            case "mine_block" -> stepMine(mc, p);
            case "tunnel" -> stepTunnel(mc, p);
            case "attack_nearest" -> stepAttack(mc, p);
            case "follow_player" -> stepFollow(mc, p);
            case "select_slot" -> {
                int s = (int) Json.num(cur, "slot", 0);
                if (s >= 1 && s <= 9) p.getInventory().selectedSlot = s - 1;
                yield true;
            }
            case "select_item" -> stepSelectItem(p);
            default -> true; // unknown action: skip it
        };
    }

    // ------------------------------------------------------------------ actions

    private static boolean stepWalk(MinecraftClient mc, ClientPlayerEntity p) {
        if (anchor == null) {
            if (cur.has("x") && cur.has("z")) {
                anchor = new Vec3d(Json.num(cur, "x", p.getX()), Json.num(cur, "y", p.getY()), Json.num(cur, "z", p.getZ()));
            } else {
                anchor = p.getPos().add(Json.num(cur, "dx", 0), Json.num(cur, "dy", 0), Json.num(cur, "dz", 0));
            }
        }
        int r = walkToward(mc, p, anchor, Json.bool(cur, "sprint"), 1.2);
        if (r == FAILED) abort();
        return r != MOVING;
    }

    private static boolean stepHold(MinecraftClient mc, ClientPlayerEntity p) {
        KeyBinding kb = keyFor(mc, Json.str(cur, "key").toLowerCase(Locale.ROOT));
        if (kb == null) return true;
        if (kb == mc.options.attackKey) {
            // Breaking blocks works by simply holding the key. Hitting mobs needs real "clicks" and is gated.
            if (mc.crosshairTarget instanceof EntityHitResult ehr) {
                setKey(kb, false);
                if (combatAllowed(mc) && isSafeTarget(ehr.getEntity()) && p.getAttackCooldownProgress(0.5f) >= 0.95f) {
                    KeyBinding.onKeyPressed(KeyBindingHelper.getBoundKeyOf(kb));
                }
                return false;
            }
        }
        setKey(kb, true);
        return false;
    }

    private static boolean stepMine(MinecraftClient mc, ClientPlayerEntity p) {
        ClientWorld w = mc.world;
        if (toolAlmostBroken(p)) {
            BuddyHud.say("My tool is about to break, so I stopped.");
            abort();
            return true;
        }
        if (blockTarget == null) {
            blockTarget = BlockPos.ofFloored(Json.num(cur, "x", p.getX()), Json.num(cur, "y", p.getY()), Json.num(cur, "z", p.getZ()));
        }
        BlockState bs = w.getBlockState(blockTarget);
        if (bs.isAir() || !bs.getFluidState().isEmpty()) return true; // already gone (or not minable)

        Vec3d center = Vec3d.ofCenter(blockTarget);
        if (p.getEyePos().distanceTo(center) > 4.0) {
            setKey(mc.options.attackKey, false);
            int r = walkToward(mc, p, center, false, 1.5);
            if (r == FAILED) {
                abort();
                return true;
            }
            if (r == ARRIVED) {
                BuddyHud.say("I can't reach that block.");
                abort();
                return true;
            }
            return false;
        }
        stopMoving(mc);
        faceTarget(p, center);
        setKey(mc.options.attackKey, true);
        return false;
    }

    /**
     * Digs a 1x2 tunnel straight ahead (the direction is locked to the nearest compass direction when it starts).
     * Each tick: mine whatever solid block is in the way, otherwise step forward. Stops at lava/water/drops.
     */
    private static boolean stepTunnel(MinecraftClient mc, ClientPlayerEntity p) {
        ClientWorld w = mc.world;
        if (toolAlmostBroken(p)) {
            BuddyHud.say("My tool is about to break, so I stopped.");
            abort();
            return true;
        }
        if (anchor == null) anchor = new Vec3d(Math.round(p.getYaw() / 90f) * 90f, 0, 0); // locked yaw
        float yaw = (float) anchor.x;
        Direction dir = Direction.fromRotation(yaw);

        Box box = p.getBoundingBox().offset(dir.getOffsetX() * 0.55, 0, dir.getOffsetZ() * 0.55);
        int x0 = MathHelper.floor(box.minX), x1 = MathHelper.floor(box.maxX - 1.0E-4);
        int z0 = MathHelper.floor(box.minZ), z1 = MathHelper.floor(box.maxZ - 1.0E-4);
        int y0 = MathHelper.floor(box.minY + 0.01);

        // Hazards two blocks ahead (and a block below / above): fluids end the task.
        Box far = p.getBoundingBox().offset(dir.getOffsetX() * 1.6, 0, dir.getOffsetZ() * 1.6);
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int x = MathHelper.floor(far.minX); x <= MathHelper.floor(far.maxX - 1.0E-4); x++) {
            for (int z = MathHelper.floor(far.minZ); z <= MathHelper.floor(far.maxZ - 1.0E-4); z++) {
                for (int y = y0 - 1; y <= y0 + 2; y++) {
                    m.set(x, y, z);
                    if (!w.getFluidState(m).isEmpty()) {
                        BuddyHud.say("I found water or lava ahead, so I stopped digging.");
                        abort();
                        return true;
                    }
                }
            }
        }

        // The nearest solid block in our way (feet or head level)
        BlockPos target = null;
        for (int y = y0; y <= y0 + 1 && target == null; y++) {
            for (int x = x0; x <= x1 && target == null; x++) {
                for (int z = z0; z <= z1; z++) {
                    m.set(x, y, z);
                    if (!w.getBlockState(m).getCollisionShape(w, m).isEmpty()) {
                        target = m.toImmutable();
                        break;
                    }
                }
            }
        }

        if (target != null) {
            stuck = target.equals(blockTarget) ? stuck + 1 : 0;
            blockTarget = target;
            if (stuck > 400) {
                BuddyHud.say("I can't break that block with this tool, so I stopped.");
                abort();
                return true;
            }
            stopMoving(mc);
            faceTarget(p, Vec3d.ofCenter(target));
            setKey(mc.options.attackKey, true);
            return false;
        }

        setKey(mc.options.attackKey, false);
        turnTo(p, yaw, 0f);
        if (!moveForward(mc, p, false)) {
            BuddyHud.say("There's a big drop ahead, so I stopped digging.");
            abort();
            return true;
        }
        return false;
    }

    private static boolean toolAlmostBroken(ClientPlayerEntity p) {
        ItemStack held = p.getMainHandStack();
        return held.isDamageable() && held.getMaxDamage() - held.getDamage() <= 3;
    }

    private static boolean stepAttack(MinecraftClient mc, ClientPlayerEntity p) {
        if (!combatAllowed(mc)) {
            BuddyHud.say("Combat control is off here, so I won't fight for you.");
            abort();
            return true;
        }
        LivingEntity target = nearestTarget(mc, p, Json.str(cur, "target").toLowerCase(Locale.ROOT).trim());
        if (target == null) return true; // nothing to fight
        faceTarget(p, target.getPos().add(0, target.getHeight() * 0.6, 0));
        double d = p.distanceTo(target);
        if (d > 2.6) {
            if (!moveForward(mc, p, d > 6 && p.getHungerManager().getFoodLevel() > 6)) {
                BuddyHud.say("Too risky to go there, there's a drop or lava.");
                abort();
                return true;
            }
        } else {
            stopMoving(mc);
        }
        if (d <= 3.2 && p.getAttackCooldownProgress(0.5f) >= 0.95f
                && mc.crosshairTarget instanceof EntityHitResult ehr && ehr.getEntity() == target) {
            KeyBinding.onKeyPressed(KeyBindingHelper.getBoundKeyOf(mc.options.attackKey));
        }
        return false;
    }

    private static boolean stepFollow(MinecraftClient mc, ClientPlayerEntity p) {
        String name = Json.str(cur, "name");
        PlayerEntity target = null;
        for (AbstractClientPlayerEntity o : mc.world.getPlayers()) {
            if (o != p && o != Companion.entity() && o.getName().getString().equalsIgnoreCase(name)) target = o;
        }
        if (target == null) {
            BuddyHud.say("I can't see " + WorldContext.clean(name) + " nearby.");
            abort();
            return true;
        }
        double d = p.distanceTo(target);
        if (d > 3.0) {
            int r = walkToward(mc, p, target.getPos(), d > 10, 3.0);
            if (r == FAILED) {
                abort();
                return true;
            }
        } else {
            setKey(mc.options.forwardKey, false);
            setKey(mc.options.sprintKey, false);
        }
        return false;
    }

    private static boolean stepSelectItem(ClientPlayerEntity p) {
        String want = Json.str(cur, "name").toLowerCase(Locale.ROOT).trim().replace(' ', '_');
        if (want.isEmpty()) return true;
        for (int i = 0; i < 9; i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (!st.isEmpty() && Registries.ITEM.getId(st.getItem()).getPath().contains(want)) {
                p.getInventory().selectedSlot = i;
                return true;
            }
        }
        BuddyHud.say("I can't find " + WorldContext.clean(want) + " in your hotbar.");
        return true;
    }

    // ----------------------------------------------------------------- movement

    private static void stopMoving(MinecraftClient mc) {
        setKey(mc.options.forwardKey, false);
        setKey(mc.options.sprintKey, false);
        setKey(mc.options.jumpKey, false);
    }

    private static int walkToward(MinecraftClient mc, ClientPlayerEntity p, Vec3d target, boolean sprint, double stopDist) {
        double dx = target.x - p.getX();
        double dz = target.z - p.getZ();
        if (Math.hypot(dx, dz) < stopDist) {
            stopMoving(mc);
            return ARRIVED;
        }
        float want = (float) (MathHelper.atan2(dz, dx) * 57.29577951308232) - 90f;
        float diff = MathHelper.wrapDegrees(want - p.getYaw());
        p.setYaw(p.getYaw() + MathHelper.clamp(diff, -30f, 30f));
        if (Math.abs(diff) > 45f) {
            setKey(mc.options.forwardKey, false); // turn first, then walk
            return MOVING;
        }
        if (!moveForward(mc, p, sprint && p.getHungerManager().getFoodLevel() > 6)) {
            BuddyHud.say("Hold on, there's a big drop or lava ahead. I'm stopping.");
            return FAILED;
        }
        if (ticks % 20 == 19) {
            Vec3d pos = p.getPos();
            stuck = (lastCheck != null && pos.squaredDistanceTo(lastCheck) < 0.04) ? stuck + 1 : 0;
            lastCheck = pos;
            if (stuck >= 4) {
                BuddyHud.say("I'm stuck, I can't get there.");
                return FAILED;
            }
        }
        return MOVING;
    }

    /** Presses forward (and jump when blocked or swimming). Returns false if lava or a big drop is right ahead. */
    private static boolean moveForward(MinecraftClient mc, ClientPlayerEntity p, boolean sprint) {
        if (unsafeAhead(mc.world, p)) {
            stopMoving(mc);
            return false;
        }
        setKey(mc.options.forwardKey, true);
        setKey(mc.options.sprintKey, sprint);
        setKey(mc.options.jumpKey, p.isTouchingWater() || (p.horizontalCollision && p.isOnGround()));
        return true;
    }

    private static boolean unsafeAhead(ClientWorld w, ClientPlayerEntity p) {
        if (!p.isOnGround()) return false;
        double yaw = Math.toRadians(p.getYaw());
        BlockPos ahead = BlockPos.ofFloored(p.getX() - Math.sin(yaw) * 1.2, p.getY(), p.getZ() + Math.cos(yaw) * 1.2);
        for (int i = 0; i <= 4; i++) {
            BlockPos q = ahead.down(i);
            FluidState fs = w.getFluidState(q);
            if (fs.isIn(FluidTags.LAVA)) return true;
            if (!w.getBlockState(q).getCollisionShape(w, q).isEmpty() || !fs.isEmpty()) return false;
        }
        return true; // four or more blocks of nothing: a drop that would hurt
    }

    // ------------------------------------------------------------------ looking

    private static boolean turnTo(ClientPlayerEntity p, float yaw, float pitch) {
        float dy = MathHelper.wrapDegrees(yaw - p.getYaw());
        float dp = pitch - p.getPitch();
        final float step = 18f;
        p.setYaw(p.getYaw() + MathHelper.clamp(dy, -step, step));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(dp, -step, step), -90f, 90f));
        return Math.abs(dy) < 2f && Math.abs(dp) < 2f;
    }

    private static boolean faceTarget(ClientPlayerEntity p, Vec3d t) {
        Vec3d d = t.subtract(p.getEyePos());
        float yaw = (float) (MathHelper.atan2(d.z, d.x) * 57.29577951308232) - 90f;
        float pitch = (float) -(MathHelper.atan2(d.y, Math.hypot(d.x, d.z)) * 57.29577951308232);
        return turnTo(p, yaw, pitch);
    }

    // ------------------------------------------------------------------- combat

    private static boolean combatAllowed(MinecraftClient mc) {
        BuddyConfig c = BuddyConfig.get();
        return c.allowCombat && (mc.isInSingleplayer() || c.allowCombatOnServers);
    }

    /** Never other players, pets, villagers, or Buddy's own avatar. */
    private static boolean isSafeTarget(net.minecraft.entity.Entity e) {
        if (!(e instanceof LivingEntity) || e == Companion.entity()) return false;
        if (e instanceof PlayerEntity || e instanceof MerchantEntity) return false;
        return !(e instanceof TameableEntity t && t.isTamed());
    }

    private static LivingEntity nearestTarget(MinecraftClient mc, ClientPlayerEntity p, String want) {
        boolean hostileOnly = want.isEmpty() || want.equals("hostile") || want.equals("any") || want.equals("monster");
        LivingEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(16), x -> x.isAlive() && isSafeTarget(x))) {
            boolean ok = hostileOnly
                    ? e.getType().getSpawnGroup() == SpawnGroup.MONSTER
                    : Registries.ENTITY_TYPE.getId(e.getType()).getPath().contains(want.replace(' ', '_'));
            if (!ok) continue;
            double d = p.squaredDistanceTo(e);
            if (d < bestD) {
                bestD = d;
                best = e;
            }
        }
        return best;
    }

    // --------------------------------------------------------------------- keys

    private static KeyBinding keyFor(MinecraftClient mc, String name) {
        var o = mc.options;
        return switch (name) {
            case "forward" -> o.forwardKey;
            case "back" -> o.backKey;
            case "left" -> o.leftKey;
            case "right" -> o.rightKey;
            case "jump" -> o.jumpKey;
            case "sneak" -> o.sneakKey;
            case "sprint" -> o.sprintKey;
            case "attack" -> o.attackKey;
            case "use" -> o.useKey;
            default -> null;
        };
    }

    /** Sets a key only when its state changes; also copes with "toggle sprint/sneak" accessibility options. */
    private static void setKey(KeyBinding kb, boolean down) {
        if (kb.isPressed() != down) {
            kb.setPressed(down);
            if (kb.isPressed() != down) kb.setPressed(true); // toggle-mode keys flip on every press
        }
        if (down) held.add(kb);
        else held.remove(kb);
    }

    private static void releaseAll() {
        for (KeyBinding kb : new HashSet<>(held)) setKey(kb, false);
        held.clear();
    }
}
