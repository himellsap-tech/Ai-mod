package com.gamebuddy;

import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.TargetDataLine;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

/** Push-to-talk microphone capture: 16 kHz, 16-bit, mono, returned as a WAV file. Max 30 seconds. */
final class MicRecorder {
    private MicRecorder() {}

    private static final AudioFormat FORMAT = new AudioFormat(16000f, 16, 1, true, false);
    private static final int MAX_BYTES = 16000 * 2 * 30;
    private static final int MIN_BYTES = (int) (16000 * 2 * 0.4);

    private static TargetDataLine line;
    private static ByteArrayOutputStream pcm;
    private static Thread reader;
    private static volatile boolean running;

    static synchronized boolean start() {
        if (running) return true;
        try {
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, FORMAT);
            if (!AudioSystem.isLineSupported(info)) return false;
            TargetDataLine l = (TargetDataLine) AudioSystem.getLine(info);
            l.open(FORMAT);
            l.start();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            line = l;
            pcm = out;
            running = true;
            reader = new Thread(() -> {
                byte[] buf = new byte[3200];
                while (running) {
                    int n = l.read(buf, 0, buf.length);
                    if (n <= 0) break;
                    synchronized (out) {
                        if (out.size() >= MAX_BYTES) break;
                        out.write(buf, 0, n);
                    }
                }
            }, "gamebuddy-mic");
            reader.setDaemon(true);
            reader.start();
            return true;
        } catch (Exception e) {
            GameBuddyClient.LOGGER.warn("Microphone unavailable: {}", e.toString());
            running = false;
            return false;
        }
    }

    /** Stops recording and returns a WAV file, or null if nothing useful was recorded. */
    static synchronized byte[] stop() {
        if (!running) return null;
        running = false;
        try {
            line.stop();
            line.close();
        } catch (Exception ignored) {
            // already closed
        }
        try {
            reader.join(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        byte[] data;
        synchronized (pcm) {
            data = pcm.toByteArray();
        }
        if (data.length < MIN_BYTES) return null;
        try (AudioInputStream ais = new AudioInputStream(new ByteArrayInputStream(data), FORMAT, data.length / 2)) {
            ByteArrayOutputStream wav = new ByteArrayOutputStream();
            AudioSystem.write(ais, AudioFileFormat.Type.WAVE, wav);
            return wav.toByteArray();
        } catch (Exception e) {
            GameBuddyClient.LOGGER.warn("Could not encode microphone audio: {}", e.toString());
            return null;
        }
    }
}
