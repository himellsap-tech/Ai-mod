package com.gamebuddy;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.BlockState;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Builds the plain-text "GAME STATE" snapshot that is sent to Gemini with each request. Runs on the main thread. */
final class WorldContext {
    private WorldContext() {}

    static String describe(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null) return "The player is not in a world right now (menu screen).";
        BuddyConfig cfg = BuddyConfig.get();
        StringBuilder sb = new StringBuilder();
        BlockPos bp = p.getBlockPos();

        sb.append("Mode: ").append(mc.isInSingleplayer() ? "singleplayer" : "multiplayer server").append('\n');
        sb.append("Dimension: ").append(w.getRegistryKey().getValue()).append('\n');
        w.getBiome(bp).getKey().ifPresent(k -> sb.append("Biome: ").append(k.getValue()).append('\n'));
        sb.append(String.format(Locale.ROOT, "Position: x=%.1f y=%.1f z=%.1f%n", p.getX(), p.getY(), p.getZ()));
        sb.append(String.format(Locale.ROOT, "Facing: %s (yaw %.0f, pitch %.0f)%n", p.getHorizontalFacing().asString(), p.getYaw(), p.getPitch()));
        sb.append(String.format(Locale.ROOT, "Health: %.1f/%.1f, armor points: %d, food: %d/20, xp level: %d%n",
                p.getHealth(), p.getMaxHealth(), p.getArmor(), p.getHungerManager().getFoodLevel(), p.experienceLevel));
        long t = w.getTimeOfDay() % 24000L;
        sb.append("Time: ").append(t < 13000 ? "day" : "night").append(" (tick ").append(t).append(")");
        if (w.isThundering()) sb.append(", thunderstorm");
        else if (w.isRaining()) sb.append(", raining");
        sb.append('\n');

        // Held item, hotbar, armor
        sb.append("Held: ").append(stackName(p.getMainHandStack())).append('\n');
        sb.append("Hotbar:");
        for (int i = 0; i < 9; i++) sb.append(' ').append(i + 1).append('=').append(stackName(p.getInventory().getStack(i)));
        sb.append('\n');
        sb.append("Armor:");
        for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            sb.append(' ').append(stackName(p.getEquippedStack(s)));
        }
        sb.append('\n');

        // Inventory totals
        Map<String, Integer> totals = new LinkedHashMap<>();
        for (int i = 0; i < 36; i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (!st.isEmpty()) totals.merge(Registries.ITEM.getId(st.getItem()).getPath(), st.getCount(), Integer::sum);
        }
        sb.append("Inventory totals:");
        if (totals.isEmpty()) sb.append(" empty");
        int shown = 0;
        for (Map.Entry<String, Integer> e : totals.entrySet()) {
            if (shown++ >= 30) {
                sb.append(" ...");
                break;
            }
            sb.append(' ').append(e.getKey()).append(" x").append(e.getValue()).append(';');
        }
        sb.append('\n');

        // Crosshair
        HitResult hr = mc.crosshairTarget;
        if (hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK) {
            BlockPos hp = bhr.getBlockPos();
            sb.append("Looking at block: ").append(Registries.BLOCK.getId(w.getBlockState(hp).getBlock()).getPath())
                    .append(" at ").append(hp.getX()).append(' ').append(hp.getY()).append(' ').append(hp.getZ()).append('\n');
        } else if (hr instanceof EntityHitResult ehr) {
            sb.append("Looking at entity: ").append(entityName(ehr.getEntity(), cfg)).append('\n');
        }

        // Nearby living things
        List<LivingEntity> near = w.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(20),
                e -> e != p && e.isAlive() && e != Companion.entity());
        Map<String, double[]> groups = new LinkedHashMap<>(); // name -> {count, nearestDist, x, y, z, hostile}
        int others = 0;
        StringBuilder playerNames = new StringBuilder();
        for (LivingEntity e : near) {
            if (e instanceof PlayerEntity pe) {
                others++;
                if (cfg.sendPlayerList) playerNames.append(clean(pe.getName().getString())).append(", ");
                continue;
            }
            String name = Registries.ENTITY_TYPE.getId(e.getType()).getPath();
            double d = p.distanceTo(e);
            double[] g = groups.computeIfAbsent(name, k -> new double[]{0, Double.MAX_VALUE, 0, 0, 0,
                    e.getType().getSpawnGroup() == SpawnGroup.MONSTER ? 1 : 0});
            g[0]++;
            if (d < g[1]) {
                g[1] = d;
                g[2] = e.getX();
                g[3] = e.getY();
                g[4] = e.getZ();
            }
        }
        sb.append("Nearby creatures (20 blocks):");
        if (groups.isEmpty()) sb.append(" none");
        sb.append('\n');
        int lines = 0;
        for (Map.Entry<String, double[]> e : groups.entrySet()) {
            if (lines++ >= 12) break;
            double[] g = e.getValue();
            sb.append("  ").append(e.getKey()).append(" x").append((int) g[0]).append(g[5] == 1 ? " (hostile)" : "")
                    .append(String.format(Locale.ROOT, ", nearest %.1f blocks at %.0f %.0f %.0f%n", g[1], g[2], g[3], g[4]));
        }
        if (others > 0) {
            sb.append("Other players nearby: ").append(others);
            if (cfg.sendPlayerList && playerNames.length() > 2) {
                sb.append(" (").append(playerNames, 0, playerNames.length() - 2).append(')');
            }
            sb.append('\n');
        }

        sb.append(scanBlocks(w, bp));
        return sb.toString();
    }

    /** Finds the nearest block of each "interesting" kind (logs, ores, water, lava, utility blocks) around the player. */
    private static String scanBlocks(ClientWorld w, BlockPos center) {
        final int rx = 12, ry = 8, rz = 12;
        Map<String, long[]> nearest = new LinkedHashMap<>(); // id -> {distSq, x, y, z}
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -rx; dx <= rx; dx++) {
            for (int dy = -ry; dy <= ry; dy++) {
                for (int dz = -rz; dz <= rz; dz++) {
                    m.set(center.getX() + dx, center.getY() + dy, center.getZ() + dz);
                    BlockState st = w.getBlockState(m);
                    if (st.isAir()) continue;
                    String id = Registries.BLOCK.getId(st.getBlock()).getPath();
                    if (!interesting(id)) continue;
                    long d = (long) dx * dx + (long) dy * dy + (long) dz * dz;
                    long[] cur = nearest.get(id);
                    if (cur == null || d < cur[0]) nearest.put(id, new long[]{d, m.getX(), m.getY(), m.getZ()});
                }
            }
        }
        StringBuilder sb = new StringBuilder("NEARBY BLOCKS (nearest of each kind):");
        if (nearest.isEmpty()) return sb.append(" nothing notable\n").toString();
        sb.append('\n');
        int n = 0;
        for (Map.Entry<String, long[]> e : nearest.entrySet()) {
            if (n++ >= 16) break;
            long[] v = e.getValue();
            sb.append("  ").append(e.getKey()).append(String.format(Locale.ROOT, " at %d %d %d (%.1f blocks)%n",
                    v[1], v[2], v[3], Math.sqrt(v[0])));
        }
        return sb.toString();
    }

    private static boolean interesting(String id) {
        return id.endsWith("_log") || id.endsWith("_ore") || id.equals("ancient_debris")
                || id.equals("water") || id.equals("lava")
                || id.equals("crafting_table") || id.equals("furnace") || id.equals("chest")
                || id.equals("spawner") || id.equals("obsidian");
    }

    private static String stackName(ItemStack s) {
        if (s.isEmpty()) return "empty";
        return Registries.ITEM.getId(s.getItem()).getPath() + (s.getCount() > 1 ? "x" + s.getCount() : "");
    }

    private static String entityName(net.minecraft.entity.Entity e, BuddyConfig cfg) {
        if (e instanceof PlayerEntity pe) return cfg.sendPlayerList ? "player " + clean(pe.getName().getString()) : "a player";
        return Registries.ENTITY_TYPE.getId(e.getType()).getPath();
    }

    /** Names come from the world and are untrusted: strip control characters and cap the length. */
    static String clean(String s) {
        String c = s.replaceAll("[\\p{Cntrl}]", " ").trim();
        return c.length() > 32 ? c.substring(0, 32) : c;
    }
}
