package com.gamebuddy;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * GameBuddy: a client-only Fabric mod. It adds no mixins and touches no rendering code,
 * so it plays nicely with Sodium, Iris, Lithium and friends, and it needs nothing installed on a server.
 */
public class GameBuddyClient implements ClientModInitializer {
    public static final String MOD_ID = "gamebuddy";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static KeyBinding openKey;
    public static KeyBinding talkKey;
    public static KeyBinding stopKey;

    private static boolean talking = false;
    private static boolean talkWasDown = false;

    @Override
    public void onInitializeClient() {
        BuddyConfig.load();

        openKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.gamebuddy.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, "category.gamebuddy"));
        talkKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.gamebuddy.talk", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "category.gamebuddy"));
        stopKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.gamebuddy.stop", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_X, "category.gamebuddy"));

        // Character actions are applied before the game reads your keys for this tick.
        ClientTickEvents.START_CLIENT_TICK.register(ActionRunner::tick);
        ClientTickEvents.END_CLIENT_TICK.register(GameBuddyClient::endTick);
        HudRenderCallback.EVENT.register(BuddyHud::render);

        // Optional: /buddy <message>. Fabric client commands are never sent to the server or shown in chat.
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("buddy")
                        .then(ClientCommandManager.argument("message", StringArgumentType.greedyString())
                                .executes(ctx -> {
                                    BuddyBrain.ask(StringArgumentType.getString(ctx, "message"), null);
                                    return 1;
                                }))));

        // The avatar is client-side only, so never send interaction packets that mention it.
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) ->
                entity == Companion.entity() ? ActionResult.FAIL : ActionResult.PASS);
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) ->
                entity == Companion.entity() ? ActionResult.FAIL : ActionResult.PASS);

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            ActionRunner.cancel(null);
            BuddyBrain.reset();
            TtsPlayer.stop();
            Companion.reset();
        });

        LOGGER.info("GameBuddy loaded. Press B to open the menu, hold V to talk, X to stop.");
    }

    private static void endTick(MinecraftClient client) {
        Companion.tick(client);

        if (client.player == null) return;

        while (openKey.wasPressed()) {
            if (client.currentScreen == null) client.setScreen(new BuddyScreen());
        }
        while (stopKey.wasPressed()) {
            ActionRunner.cancel("Stopped.");
            TtsPlayer.stop();
            BuddyBrain.cancel();
        }

        // Push-to-talk
        boolean down = talkKey.isPressed() && client.currentScreen == null;
        if (down && !talkWasDown) {
            TtsPlayer.stop();
            if (!BuddyConfig.get().hasKey()) {
                BuddyHud.say("I need your Gemini API key first. Put it in config/gamebuddy.json.");
            } else if (MicRecorder.start()) {
                talking = true;
                BuddyHud.setStatus("is listening...");
            } else {
                BuddyHud.say("I can't open your microphone.");
            }
        } else if (!down && talking) {
            talking = false;
            BuddyHud.setStatus("");
            byte[] wav = MicRecorder.stop();
            if (wav != null) BuddyBrain.ask("", wav);
            else BuddyHud.say("I didn't catch that.");
        }
        talkWasDown = down;
    }
}
