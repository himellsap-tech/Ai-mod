package com.gamebuddy;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

import java.util.List;

/** On-screen captions and status. Buddy never posts to the Minecraft chat. */
public final class BuddyHud {
    private BuddyHud() {}

    private static volatile String caption = "";
    private static volatile long captionUntil = 0;
    private static volatile String status = "";
    private static volatile String action = "";

    public static void say(String text) {
        String t = text == null ? "" : text.trim();
        caption = t;
        long seconds = Math.max(4, Math.min(30, BuddyConfig.get().captionSeconds + t.length() / 40));
        captionUntil = System.currentTimeMillis() + seconds * 1000L;
    }

    public static void setStatus(String s) {
        status = s == null ? "" : s;
    }

    public static void setAction(String s) {
        action = s == null ? "" : s;
    }

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        BuddyConfig cfg = BuddyConfig.get();
        TextRenderer tr = mc.textRenderer;
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();

        // Small status pill (top-left): listening / thinking / current action
        String line = !status.isEmpty() ? status : (!action.isEmpty() ? "doing: " + action.replace('_', ' ') : "");
        if (!line.isEmpty()) {
            Text t = Text.literal("● " + cfg.buddyName + " " + line);
            int w = tr.getWidth(t) + 8;
            ctx.fill(4, 4, 4 + w, 16, 0x99000000);
            ctx.drawTextWithShadow(tr, t, 8, 6, 0xFF55FFAA);
        }

        // Caption box above the hotbar
        if (cfg.captions && !caption.isEmpty() && System.currentTimeMillis() < captionUntil) {
            int maxW = Math.min(300, sw - 40);
            List<OrderedText> lines = tr.wrapLines(Text.literal(caption), maxW);
            if (lines.isEmpty()) return;
            int textW = 0;
            for (OrderedText l : lines) textW = Math.max(textW, tr.getWidth(l));
            int boxW = Math.max(textW, tr.getWidth(cfg.buddyName)) + 12;
            int boxH = lines.size() * 10 + 8 + 11;
            int x = (sw - boxW) / 2;
            int y = sh - 72 - boxH;
            ctx.fill(x, y, x + boxW, y + boxH, 0xB0101418);
            ctx.drawBorder(x, y, boxW, boxH, 0xFF3DDC97);
            ctx.drawTextWithShadow(tr, Text.literal(cfg.buddyName), x + 6, y + 4, 0xFF55FFAA);
            int ty = y + 15;
            for (OrderedText l : lines) {
                ctx.drawTextWithShadow(tr, l, x + 6, ty, 0xFFFFFFFF);
                ty += 10;
            }
        }
    }
}
