package com.gamebuddy;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * The Buddy control panel: a command bar, quick questions and switches.
 * Answers are NOT shown here. They are spoken and shown as a small caption on your HUD.
 */
public final class BuddyScreen extends Screen {
    private static final int W = 300;
    private static final int H = 208;

    private TextFieldWidget input;
    private int px;
    private int py;

    public BuddyScreen() {
        super(Text.literal("Buddy"));
    }

    @Override
    protected void init() {
        BuddyConfig cfg = BuddyConfig.get();
        px = (width - W) / 2;
        py = Math.max(10, (height - H) / 2 - 20);

        input = new TextFieldWidget(textRenderer, px + 10, py + 30, W - 20, 20, Text.literal("Message"));
        input.setMaxLength(300);
        input.setPlaceholder(Text.literal("Tell " + cfg.buddyName + " what to do, or ask anything..."));
        addDrawableChild(input);
        setInitialFocus(input);

        int half = (W - 30) / 2;
        int left = px + 10;
        int right = px + 20 + half;

        addDrawableChild(ButtonWidget.builder(Text.literal("Send"), b -> send(input.getText()))
                .dimensions(left, py + 56, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Stop everything"), b -> stopAll())
                .dimensions(right, py + 56, half, 20).build());

        String[][] quick = {
                {"What next?", "What should I do next?"},
                {"Quick tip", "Give me one useful tip for my situation right now."},
                {"Any danger?", "Is there any danger around me right now?"},
                {"What's this?", "What am I looking at? Tell me what it is and what I can do with it."}
        };
        for (int i = 0; i < quick.length; i++) {
            final String prompt = quick[i][1];
            int x = (i % 2 == 0) ? left : right;
            int y = py + 84 + (i / 2) * 24;
            addDrawableChild(ButtonWidget.builder(Text.literal(quick[i][0]), b -> send(prompt))
                    .dimensions(x, y, half, 20).build());
        }

        addDrawableChild(toggle(left, py + 138, half, "Voice", () -> cfg.voiceReplies, v -> {
            cfg.voiceReplies = v;
            if (!v) TtsPlayer.stop();
        }));
        addDrawableChild(toggle(right, py + 138, half, "Captions", () -> cfg.captions, v -> cfg.captions = v));
        addDrawableChild(toggle(left, py + 162, half, "Control me", () -> cfg.allowCharacterControl, v -> {
            cfg.allowCharacterControl = v;
            if (!v) ActionRunner.cancel(null);
        }));
        addDrawableChild(toggle(right, py + 162, half, "Avatar", () -> cfg.showAvatar, v -> cfg.showAvatar = v));
    }

    private ButtonWidget toggle(int x, int y, int w, String label, Supplier<Boolean> get, Consumer<Boolean> set) {
        return ButtonWidget.builder(toggleText(label, get.get()), b -> {
            set.accept(!get.get());
            BuddyConfig.save();
            b.setMessage(toggleText(label, get.get()));
        }).dimensions(x, y, w, 20).build();
    }

    private static Text toggleText(String label, boolean on) {
        return Text.literal(label + ": " + (on ? "ON" : "OFF"));
    }

    private void send(String text) {
        String t = text == null ? "" : text.trim();
        if (t.isEmpty()) return;
        BuddyBrain.ask(t, null);
        input.setText("");
        if (BuddyConfig.get().closeGuiOnSend) close();
    }

    private void stopAll() {
        ActionRunner.cancel("Okay, stopped.");
        TtsPlayer.stop();
        BuddyBrain.cancel();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (input.isFocused() && (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)) {
            send(input.getText());
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    /** No blur and no darkening: the world stays visible behind the panel. */
    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(px, py, px + W, py + H, 0xDD101418);
        ctx.drawBorder(px, py, W, H, 0xFF3DDC97);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        BuddyConfig cfg = BuddyConfig.get();
        ctx.drawTextWithShadow(textRenderer, Text.literal(cfg.buddyName + "  -  your game buddy"), px + 10, py + 12, 0xFF55FFAA);

        Text keyStatus = cfg.hasKey()
                ? Text.literal("Gemini key: set").styled(s -> s.withColor(0x55FF55))
                : Text.literal("Gemini key missing - edit config/gamebuddy.json").styled(s -> s.withColor(0xFF5555));
        ctx.drawTextWithShadow(textRenderer, keyStatus, px + 10, py + 188, 0xFFFFFFFF);

        Text hint = Text.literal("Hold [" + GameBuddyClient.talkKey.getBoundKeyLocalizedText().getString() + "] to talk").styled(s -> s.withColor(0xAAAAAA));
        ctx.drawTextWithShadow(textRenderer, hint, px + W - 10 - textRenderer.getWidth(hint), py + 188, 0xFFFFFFFF);
    }

    /** Keep the game running while the panel is open so you can still chat with Buddy mid-fight. */
    @Override
    public boolean shouldPause() {
        return false;
    }
}
