package com.gamebuddy;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.util.concurrent.atomic.AtomicInteger;

/** Speaks Buddy's replies with Gemini TTS. Plays through the system audio device. */
final class TtsPlayer {
    private TtsPlayer() {}

    private static final AtomicInteger GEN = new AtomicInteger();
    private static final Object LOCK = new Object();
    private static Clip current;

    static void speak(String text) {
        BuddyConfig cfg = BuddyConfig.get();
        if (!cfg.voiceReplies || !cfg.hasKey() || text == null || text.isBlank()) return;
        int mine = GEN.incrementAndGet();
        stopClip();
        GeminiClient.tts(text).whenComplete((bytes, err) -> {
            if (err != null) {
                GameBuddyClient.LOGGER.warn("Voice reply failed: {}", err.getCause() != null ? err.getCause().getMessage() : err.getMessage());
                return;
            }
            if (mine != GEN.get()) return; // a newer reply or a stop request replaced this one
            play(bytes, mine);
        });
    }

    static void stop() {
        GEN.incrementAndGet();
        stopClip();
    }

    private static void play(byte[] bytes, int mine) {
        try {
            AudioInputStream in;
            try {
                in = AudioSystem.getAudioInputStream(new BufferedInputStream(new ByteArrayInputStream(bytes)));
            } catch (UnsupportedAudioFileException notWav) {
                // Raw PCM from Gemini: 24 kHz, 16-bit, mono, little endian
                AudioFormat raw = new AudioFormat(24000f, 16, 1, true, false);
                in = new AudioInputStream(new ByteArrayInputStream(bytes), raw, bytes.length / 2);
            }
            Clip clip = AudioSystem.getClip();
            clip.open(in);
            applyVolume(clip);
            clip.addLineListener(ev -> {
                if (ev.getType() == LineEvent.Type.STOP) {
                    clip.close();
                }
            });
            synchronized (LOCK) {
                if (mine != GEN.get()) {
                    clip.close();
                    return;
                }
                current = clip;
                clip.start();
            }
        } catch (Exception e) {
            GameBuddyClient.LOGGER.warn("Could not play voice reply: {}", e.toString());
        }
    }

    private static void applyVolume(Clip clip) {
        try {
            if (clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                FloatControl gain = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                double vol = Math.max(0.0001, Math.min(1.5, BuddyConfig.get().voiceVolume));
                float db = (float) (20.0 * Math.log10(vol));
                gain.setValue(Math.max(gain.getMinimum(), Math.min(gain.getMaximum(), db)));
            }
        } catch (Exception ignored) {
            // volume control is optional
        }
    }

    private static void stopClip() {
        synchronized (LOCK) {
            if (current != null) {
                try {
                    current.stop();
                    current.close();
                } catch (Exception ignored) {
                    // already closed
                }
                current = null;
            }
        }
    }
}
