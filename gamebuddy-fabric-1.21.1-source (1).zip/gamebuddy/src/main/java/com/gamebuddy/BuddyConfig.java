package com.gamebuddy;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Settings live in  .minecraft/config/gamebuddy.json
 * Your Gemini key goes in "geminiApiKey" (or set the GEMINI_API_KEY environment variable).
 * The key is only ever sent to generativelanguage.googleapis.com, in an HTTP header. It is never logged.
 */
public final class BuddyConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("gamebuddy.json");
    private static BuddyConfig instance = new BuddyConfig();

    // --- Gemini ---
    public String geminiApiKey = "PASTE_YOUR_GEMINI_KEY_HERE";
    public String textModel = "gemini-3.8-flash";
    public String ttsModel = "gemini-3.8-flash-tts";
    public String ttsVoice = "Kore";

    // --- Buddy ---
    public String buddyName = "Buddy";
    public boolean voiceReplies = true;
    public double voiceVolume = 1.0;
    public boolean captions = true;
    public int captionSeconds = 8;
    public int historyTurns = 10;
    public boolean closeGuiOnSend = true;
    public boolean sendPlayerList = true;
    /** Client-side-only visual companion that follows you. Only you can see it, even on servers. */
    public boolean showAvatar = true;

    // --- Character control ---
    public boolean allowCharacterControl = true;
    public boolean allowControlOnServers = true;
    /** Lets Buddy hit mobs for you. Off on servers by default (many servers treat this as a combat hack). */
    public boolean allowCombat = true;
    public boolean allowCombatOnServers = false;
    public boolean stopWhenDanger = true;
    public int maxActionSeconds = 60;
    /** AFK task mode: after each batch Buddy re-checks the game and continues, for at most this many rounds. */
    public int maxAutoSteps = 40;
    /** AFK task mode on servers is OFF by default: many servers ban AFK macros. */
    public boolean allowAutoTaskOnServers = false;

    public static BuddyConfig get() {
        return instance;
    }

    public String apiKey() {
        String k = geminiApiKey == null ? "" : geminiApiKey.trim();
        if (k.isEmpty() || k.startsWith("PASTE_")) {
            String env = System.getenv("GEMINI_API_KEY");
            return env == null ? "" : env.trim();
        }
        return k;
    }

    public boolean hasKey() {
        return !apiKey().isEmpty();
    }

    public static void load() {
        try {
            if (Files.exists(PATH)) {
                try (Reader r = Files.newBufferedReader(PATH, StandardCharsets.UTF_8)) {
                    BuddyConfig loaded = GSON.fromJson(r, BuddyConfig.class);
                    if (loaded != null) instance = loaded;
                }
            }
        } catch (Exception e) {
            GameBuddyClient.LOGGER.warn("Could not read gamebuddy.json, using defaults: {}", e.toString());
        }
        save(); // writes defaults / newly added fields back
    }

    public static void save() {
        try {
            Files.createDirectories(PATH.getParent());
            Files.writeString(PATH, GSON.toJson(instance), StandardCharsets.UTF_8);
        } catch (IOException e) {
            GameBuddyClient.LOGGER.warn("Could not save gamebuddy.json: {}", e.toString());
        }
    }
}
