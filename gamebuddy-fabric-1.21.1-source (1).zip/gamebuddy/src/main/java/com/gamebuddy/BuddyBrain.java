package com.gamebuddy;

import com.google.gson.JsonElement;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletionException;
import java.util.concurrent.atomic.AtomicInteger;

/** Glue: game state in, Gemini answer out, then caption + voice + character actions (and AFK task mode). */
public final class BuddyBrain {
    private BuddyBrain() {}

    private static final List<GeminiClient.Turn> history = new ArrayList<>();
    private static final AtomicInteger generation = new AtomicInteger();

    // AFK task mode state (main thread only)
    private static boolean taskActive = false;
    private static String goal = "";
    private static int taskSteps = 0;

    public static boolean taskActive() {
        return taskActive;
    }

    /** A new instruction from the player (text and/or recorded voice). Call on the main thread. */
    public static void ask(String text, byte[] wavAudio) {
        taskActive = false; // a new instruction replaces any running task
        goal = "";
        taskSteps = 0;
        send(text, wavAudio, false);
    }

    private static void send(String text, byte[] wavAudio, boolean auto) {
        MinecraftClient mc = MinecraftClient.getInstance();
        BuddyConfig cfg = BuddyConfig.get();
        String clean = text == null ? "" : text.trim();
        if (clean.isEmpty() && wavAudio == null) return;
        if (!cfg.hasKey()) {
            taskActive = false;
            BuddyHud.say("I need your Gemini API key. Put it in config/gamebuddy.json, then restart the game.");
            return;
        }
        String state = WorldContext.describe(mc);
        List<GeminiClient.Turn> snapshot = new ArrayList<>(history);
        int gen = generation.incrementAndGet();
        BuddyHud.setStatus(auto ? "is checking in..." : "is thinking...");

        GeminiClient.chat(snapshot, state, clean, wavAudio).whenComplete((reply, err) -> mc.execute(() -> {
            if (gen != generation.get()) return; // cancelled or superseded
            BuddyHud.setStatus("");
            if (err != null) {
                Throwable t = err instanceof CompletionException && err.getCause() != null ? err.getCause() : err;
                String msg = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
                GameBuddyClient.LOGGER.warn("Gemini request failed: {}", msg);
                taskActive = false;
                BuddyHud.say("I couldn't reach Gemini, so I stopped. " + msg);
                return;
            }
            handle(clean, reply, auto);
        }));
    }

    private static void handle(String userText, GeminiClient.Reply reply, boolean auto) {
        MinecraftClient mc = MinecraftClient.getInstance();
        BuddyConfig cfg = BuddyConfig.get();

        String remembered = auto ? "(auto check-in)"
                : (!userText.isEmpty() ? userText : (reply.heard().isBlank() ? "(voice message)" : reply.heard()));
        StringBuilder said = new StringBuilder(reply.say());
        if (!reply.actions().isEmpty()) {
            said.append(" [actions:");
            for (JsonElement e : reply.actions()) {
                if (e.isJsonObject()) said.append(' ').append(Json.str(e.getAsJsonObject(), "type"));
            }
            said.append(']');
        }
        if (reply.keepGoing()) said.append(" [continue]");
        history.add(new GeminiClient.Turn("user", remembered));
        history.add(new GeminiClient.Turn("model", said.toString()));
        int max = Math.max(2, cfg.historyTurns * 2);
        while (history.size() > max) history.remove(0);

        boolean wantsTask = reply.keepGoing() && !reply.actions().isEmpty();
        if (wantsTask && !(mc.isInSingleplayer() || cfg.allowAutoTaskOnServers)) {
            wantsTask = false;
            BuddyHud.say("AFK task mode is off on servers (allowAutoTaskOnServers in my config). I'll do just one round.");
        } else if (!reply.say().isBlank()) {
            BuddyHud.say(reply.say());
            // During automatic check-ins stay quiet; only the first answer and the final answer are spoken.
            if (!(auto && reply.keepGoing())) TtsPlayer.speak(reply.say());
        }

        boolean started = !reply.actions().isEmpty() && ActionRunner.start(reply.actions());
        taskActive = wantsTask && started;
        if (taskActive) {
            if (!reply.goal().isBlank()) goal = WorldContext.clean(reply.goal());
        } else {
            goal = "";
            taskSteps = 0;
        }
    }

    /** Called by ActionRunner when a batch of actions finished by itself (not cancelled). */
    static void onActionsDone() {
        if (!taskActive) return;
        BuddyConfig cfg = BuddyConfig.get();
        if (taskSteps >= cfg.maxAutoSteps) {
            endTask();
            BuddyHud.say("I did my maximum number of rounds, so I stopped. Tell me to continue if you want more.");
            return;
        }
        taskSteps++;
        send("[AUTO CHECK-IN] Goal: " + goal + ". The previous actions just finished. Give the next actions to continue the goal, "
                + "or set continue=false if the goal is done or it is unsafe.", null, true);
    }

    /** Ends the AFK task and drops any request still in flight. */
    static void endTask() {
        taskActive = false;
        goal = "";
        taskSteps = 0;
        cancel();
    }

    /** Drops any request still in flight. */
    public static void cancel() {
        generation.incrementAndGet();
        BuddyHud.setStatus("");
    }

    /** Forget the conversation (used when leaving a world). */
    public static void reset() {
        endTask();
        history.clear();
    }
}
