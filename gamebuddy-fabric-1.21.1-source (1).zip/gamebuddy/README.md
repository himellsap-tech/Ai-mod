# GameBuddy (Fabric 1.21.1, client-only)

An AI gaming buddy for Minecraft powered by your own Gemini API key.

- **Talks to you**: type in the Buddy panel (`B`), use `/buddy <message>`, or hold `V` and speak (push-to-talk).
- **Answers by voice and on-screen captions**, never in the Minecraft chat and not in a chat window.
- **Game-focused**: it gets a snapshot of your game (health, hunger, time, inventory, what you're looking at, nearby mobs, nearest logs and ores) so its advice is specific.
- **Can operate your character** when you ask ("go mine that tree", "walk 20 blocks north", "kill that zombie"). It presses the same keys and turns the same camera a human would. `X` stops everything instantly.
- **A visible buddy**: a client-side player model follows you around. Only you can see it.
- **Client-only**: nothing to install on a server, so it works on servers. No mixins, so Sodium (and Iris, Lithium...) are unaffected.

## Your API key

Open `.minecraft/config/gamebuddy.json` after the first launch and put your key in `geminiApiKey`
(or set the `GEMINI_API_KEY` environment variable). The key is **not** in the jar and is never written to logs.
It is sent only to `generativelanguage.googleapis.com`, in a request header.
Don't paste your key into chats or commit the config file anywhere.

## Build

You need Java 21.

```
gradle build        # or push to GitHub: the included workflow builds the jar for you
```

The jar ends up in `build/libs/`. Put it in `.minecraft/mods/` together with **Fabric API** (and Sodium if you like).
If Gradle can't find the Fabric API version in `gradle.properties`, pick the newest `+1.21.1` version from https://fabricmc.net/develop.

## Controls

| Key | What it does |
|-----|--------------|
| `B` | Open the Buddy panel |
| `V` (hold) | Talk to Buddy |
| `X` | Stop all actions and silence Buddy |

All keys can be changed in Options > Controls > GameBuddy.

## Things to know

- Your game snapshot (coordinates, inventory, nearby creatures, nearby player names) goes to Google with each request. Turn off `sendPlayerList` in the config if you don't want player names sent.
- **Servers**: automated movement can break the rules of some servers, and some anti-cheats flag it. Hitting mobs for you is off on servers by default (`allowCombatOnServers`). You can turn off all control on servers with `allowControlOnServers`. Check the rules of the server you play on.
- Safety: Buddy stops if you catch fire, touch lava, drop to 3 hearts, open a menu, or press `X`. It won't walk into lava or off drops of 4+ blocks, and it never attacks players, pets or villagers.
- Voice: uses the Gemini TTS model in `ttsModel` (default `gemini-3.8-flash-tts`) and the voice in `ttsVoice`. Model names change over time; if a model stops working, update it in the config.
- Microphone: on macOS the launcher needs microphone permission.

## AFK task mode

Ask for something long ("dig a tunnel forward until I say stop", "collect wood") and Buddy keeps working: after each batch of
actions it looks at the game again and decides the next batch (up to `maxAutoSteps` rounds, default 40).
It stops by itself at lava or water, big drops, a nearly broken tool, low health, when something hurts it, when the
game is closed, or when you press `X` / tap "Stop everything". It pauses while a menu is open.
On servers this is OFF by default (`allowAutoTaskOnServers`): many servers ban AFK macros.
Tunnel digging needs a pickaxe in the hotbar. On a phone, keep the screen on.

## Phone launchers (PojavLauncher etc.)

If Buddy says "Network problem" or "timed out", add this to the launcher's Java arguments: `-Djava.net.preferIPv4Stack=true`
